src/lrmatrix.o: src/lrmatrix.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/init.h \
  /Users/gustav/Desktop/bart-master/src/num/ops_p.h \
  /Users/gustav/Desktop/bart-master/src/num/ops.h \
  /Users/gustav/Desktop/bart-master/src/linops/linop.h \
  /Users/gustav/Desktop/bart-master/src/linops/sum.h \
  /Users/gustav/Desktop/bart-master/src/linops/sampling.h \
  /Users/gustav/Desktop/bart-master/src/misc/mri.h \
  /Users/gustav/Desktop/bart-master/src/linops/someops.h \
  /Users/gustav/Desktop/bart-master/src/iter/iter.h \
  /Users/gustav/Desktop/bart-master/src/iter/lsqr.h \
  /Users/gustav/Desktop/bart-master/src/iter/iter2.h \
  /Users/gustav/Desktop/bart-master/src/iter/itop.h \
  /Users/gustav/Desktop/bart-master/src/iter/thresh.h \
  /Users/gustav/Desktop/bart-master/src/iter/prox2.h \
  /Users/gustav/Desktop/bart-master/src/lowrank/lrthresh.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/mmio.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/opts.h
