/Users/gustav/Desktop/bart-master/src/bitmask.o: \
  /Users/gustav/Desktop/bart-master/src/bitmask.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/opts.h
