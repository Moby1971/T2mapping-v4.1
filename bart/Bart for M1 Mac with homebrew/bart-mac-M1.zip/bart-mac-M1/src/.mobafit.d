src/mobafit.o: src/mobafit.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/ops_p.h \
  /Users/gustav/Desktop/bart-master/src/num/init.h \
  /Users/gustav/Desktop/bart-master/src/misc/mri.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/mmio.h \
  /Users/gustav/Desktop/bart-master/src/misc/utils.h \
  /Users/gustav/Desktop/bart-master/src/misc/opts.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/iter/italgos.h \
  /Users/gustav/Desktop/bart-master/src/iter/iter3.h \
  /Users/gustav/Desktop/bart-master/src/iter/iter4.h \
  /Users/gustav/Desktop/bart-master/src/iter/lsqr.h \
  /Users/gustav/Desktop/bart-master/src/iter/iter.h \
  /Users/gustav/Desktop/bart-master/src/iter/iter2.h \
  /Users/gustav/Desktop/bart-master/src/iter/itop.h \
  /Users/gustav/Desktop/bart-master/src/nlops/nlop.h \
  /Users/gustav/Desktop/bart-master/src/linops/linop.h \
  /Users/gustav/Desktop/bart-master/src/num/ops.h \
  /Users/gustav/Desktop/bart-master/src/moba/meco.h \
  /Users/gustav/Desktop/bart-master/src/simu/signals.h
