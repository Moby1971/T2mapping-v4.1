/Users/gustav/Desktop/bart-master/src/calib/ssa.o: \
  /Users/gustav/Desktop/bart-master/src/calib/ssa.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/misc/mri.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/init.h \
  /Users/gustav/Desktop/bart-master/src/num/casorati.h \
  /Users/gustav/Desktop/bart-master/src/num/lapack.h \
  /Users/gustav/Desktop/bart-master/src/num/linalg.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/calib/calib.h \
  /Users/gustav/Desktop/bart-master/src/calib/estvar.h \
  /Users/gustav/Desktop/bart-master/src/calib/calmat.h \
  /Users/gustav/Desktop/bart-master/src/calib/ssa.h
