/Users/gustav/Desktop/bart-master/src/calib/direct.o: \
  /Users/gustav/Desktop/bart-master/src/calib/direct.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/fft.h \
  /Users/gustav/Desktop/bart-master/src/num/specfun.h \
  /Users/gustav/Desktop/bart-master/src/misc/mri.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/calib/direct.h
