/Users/gustav/Desktop/bart-master/src/bart.o: \
  /Users/gustav/Desktop/bart-master/src/bart.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/misc/io.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/opts.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/misc/version.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /opt/homebrew//include/fftw3.h \
  /Users/gustav/Desktop/bart-master/src/main.h
