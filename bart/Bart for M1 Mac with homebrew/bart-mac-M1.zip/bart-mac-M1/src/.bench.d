src/bench.o: src/bench.c src/main.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppmap.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/rand.h \
  /Users/gustav/Desktop/bart-master/src/num/init.h \
  /Users/gustav/Desktop/bart-master/src/num/ops_p.h \
  /Users/gustav/Desktop/bart-master/src/num/mdfft.h \
  /Users/gustav/Desktop/bart-master/src/num/fft.h \
  /Users/gustav/Desktop/bart-master/src/wavelet/wavthresh.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/mmio.h \
  /Users/gustav/Desktop/bart-master/src/misc/opts.h
