utests/test_blas.o: utests/test_blas.c \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/blas.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/num/rand.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h utests/utest.h
