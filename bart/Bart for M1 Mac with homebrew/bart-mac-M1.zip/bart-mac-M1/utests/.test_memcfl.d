utests/test_memcfl.o: utests/test_memcfl.c utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/io.h \
  /Users/gustav/Desktop/bart-master/src/misc/mmio.h \
  /Users/gustav/Desktop/bart-master/src/misc/memcfl.h
