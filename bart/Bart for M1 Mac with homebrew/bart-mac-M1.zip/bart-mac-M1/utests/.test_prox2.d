utests/test_prox2.o: utests/test_prox2.c \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/ops_p.h \
  /Users/gustav/Desktop/bart-master/src/num/ops.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/nlops/nlop.h \
  /Users/gustav/Desktop/bart-master/src/linops/linop.h \
  /Users/gustav/Desktop/bart-master/src/nlops/tenmul.h \
  /Users/gustav/Desktop/bart-master/src/nlops/chain.h \
  /Users/gustav/Desktop/bart-master/src/iter/prox2.h \
  /Users/gustav/Desktop/bart-master/src/iter/thresh.h utests/utest.h
