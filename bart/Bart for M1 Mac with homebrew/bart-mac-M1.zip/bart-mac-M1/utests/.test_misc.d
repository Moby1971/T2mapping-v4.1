utests/test_misc.o: utests/test_misc.c \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h
