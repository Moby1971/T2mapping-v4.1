utests/test_epg.o: utests/test_epg.c \
  /Users/gustav/Desktop/bart-master/src/misc/mri.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/simu/epg.h utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h
