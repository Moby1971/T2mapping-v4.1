utests/test_padding.o: utests/test_padding.c \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/iovec.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/linops/linop.h \
  /Users/gustav/Desktop/bart-master/src/num/ops.h \
  /Users/gustav/Desktop/bart-master/src/linops/lintest.h \
  /Users/gustav/Desktop/bart-master/src/linops/someops.h utests/utest.h
