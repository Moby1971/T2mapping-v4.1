utests/test_geom.o: utests/test_geom.c \
  /Users/gustav/Desktop/bart-master/src/geom/polygon.h \
  /Users/gustav/Desktop/bart-master/src/geom/polyhedron.h \
  /Users/gustav/Desktop/bart-master/src/geom/triangle.h utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h
