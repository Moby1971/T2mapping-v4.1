utests/test_biot_savart.o: utests/test_biot_savart.c \
  /Users/gustav/Desktop/bart-master/src/num/vec3.h \
  /Users/gustav/Desktop/bart-master/src/simu/biot_savart.h \
  utests/utest.h /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h
