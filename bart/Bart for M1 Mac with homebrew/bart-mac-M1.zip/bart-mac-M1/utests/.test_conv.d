utests/test_conv.o: utests/test_conv.c \
  /Users/gustav/Desktop/bart-master/src/num/conv.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h
