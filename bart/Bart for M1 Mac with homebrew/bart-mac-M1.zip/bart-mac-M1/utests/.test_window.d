utests/test_window.o: utests/test_window.c \
  /Users/gustav/Desktop/bart-master/src/num/filter.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h
