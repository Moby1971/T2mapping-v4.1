utests/test_polynom.o: utests/test_polynom.c \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/num/polynom.h utests/utest.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h
