utests/test_batchsvd.o: utests/test_batchsvd.c \
  /Users/gustav/Desktop/bart-master/src/lowrank/batchsvd.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h utests/utest.h
