utests/test_nufft.o: utests/test_nufft.c \
  /Users/gustav/Desktop/bart-master/src/num/multind.h \
  /Users/gustav/Desktop/bart-master/src/misc/cppwrap.h \
  /Users/gustav/Desktop/bart-master/src/misc/nested.h \
  /Users/gustav/Desktop/bart-master/src/misc/types.h \
  /Users/gustav/Desktop/bart-master/src/num/flpmath.h \
  /Users/gustav/Desktop/bart-master/src/num/rand.h \
  /Users/gustav/Desktop/bart-master/src/linops/linop.h \
  /Users/gustav/Desktop/bart-master/src/num/ops.h \
  /Users/gustav/Desktop/bart-master/src/linops/lintest.h \
  /Users/gustav/Desktop/bart-master/src/noncart/nufft.h \
  /Users/gustav/Desktop/bart-master/src/misc/misc.h \
  /Users/gustav/Desktop/bart-master/src/misc/debug.h utests/utest.h
